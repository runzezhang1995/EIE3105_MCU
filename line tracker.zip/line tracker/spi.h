#include "stm32f10x.h"                  // Device header
#include "PinMap.h"

#include "stdbool.h"
#include "stdio.h"